/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\99803289                                         */
/*    Created:      Mon Aug 22 2022                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    1, 10           
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  Drivetrain.driveFor(forward, 600, mm, 50, velocityUnits::pct);
  Drivetrain.turnFor(left, 90, degrees, 15, velocityUnits::pct);
  Drivetrain.driveFor(forward, 200, mm, 50, velocityUnits::pct);
  wait(2, seconds);
  Drivetrain.driveFor(reverse, 200, mm, 50, velocityUnits::pct);
  Drivetrain.turnFor(right, 90, degrees, 15, velocityUnits::pct);
  Drivetrain.driveFor(reverse, 600, mm, 50, velocityUnits::pct);
  wait(2, seconds);
  Drivetrain.driveFor(reverse, 600, mm, 50, velocityUnits::pct);
  Drivetrain.turnFor(left, 90, degrees, 15, velocityUnits::pct);
  Drivetrain.driveFor(forward, 200, mm, 50, velocityUnits::pct);
  wait(2, seconds);
  Drivetrain.driveFor(reverse, 200, mm, 50, velocityUnits::pct);
  Drivetrain.turnFor(right, 90, degrees, 15, velocityUnits::pct);
  Drivetrain.driveFor(forward, 600, mm, 50, velocityUnits::pct);
  wait(2, seconds);
  Drivetrain.driveFor(forward, 600, mm, 50, velocityUnits::pct);
  Drivetrain.turnFor(right, 90, degrees, 15, velocityUnits::pct);
  Drivetrain.driveFor(forward, 200, mm, 50, velocityUnits::pct);
  wait(2, seconds);
  Drivetrain.driveFor(reverse, 200, mm, 50, velocityUnits::pct);
  Drivetrain.turnFor(left, 90, degrees, 15, velocityUnits::pct);
  Drivetrain.driveFor(reverse, 600, mm, 50, velocityUnits::pct);
  wait(2, seconds);
  Drivetrain.driveFor(reverse, 600, mm, 50, velocityUnits::pct);
  Drivetrain.turnFor(right, 90, degrees, 15, velocityUnits::pct);
  Drivetrain.driveFor(forward, 200, mm, 50, velocityUnits::pct);
  wait(2, seconds);
  Drivetrain.driveFor(reverse, 200, mm, 50, velocityUnits::pct);
  Drivetrain.turnFor(left, 90, degrees, 15, velocityUnits::pct);
  Drivetrain.driveFor(forward, 600, mm, 50, velocityUnits::pct);
}
